# 安卓广告拦截器

一个功能强大的安卓广告拦截应用，支持多种广告拦截技术。

## 功能特点

- **多种拦截方式**：
  - Hosts文件修改
  - VPN网络拦截
  - DNS请求过滤
  - 应用内广告识别

- **支持的广告类型**：
  - 横幅广告
  - 插屏广告
  - 视频广告
  - 原生广告
  - 激励广告

- **技术实现**：
  - Android SDK集成
  - 网络请求拦截
  - 内容过滤
  - 权限管理

## 编译说明

### 环境要求
- Android SDK 34+
- Java 8+
- Gradle 8.2+

### 编译步骤
1. 克隆项目
2. 用Android Studio打开
3. 编译生成APK
4. 安装到设备测试

### 权限说明
- INTERNET: 网络访问
- ACCESS_NETWORK_STATE: 网络状态检测
- BIND_VPN_SERVICE: VPN服务
- WRITE_EXTERNAL_STORAGE: 配置保存

## 使用方法

1. 安装应用
2. 启用广告拦截开关
3. 授权VPN权限
4. 开始拦截广告

## 注意事项

- 需要root权限修改Hosts文件
- VPN拦截需要用户授权
- 可能影响部分应用功能
- 遵守应用商店政策

## 技术架构

- MainActivity: 主界面
- NetworkInterceptor: 网络拦截
- AdBlockVpnService: VPN服务
- HostsManager: Hosts文件管理

## 许可证

MIT License