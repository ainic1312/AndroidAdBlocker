package com.example.adblocker;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

public class AdBlockVpnService extends VpnService {
    private static final String TAG = "AdBlockVpn";
    
    private Thread vpnThread;
    private ParcelFileDescriptor vpnInterface;
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 启动VPN线程
        startVpn();
        return START_STICKY;
    }
    
    private void startVpn() {
        Builder builder = new Builder();
        
        try {
            // 配置VPN
            builder.setSession("广告拦截VPN")
                   .addAddress("10.0.0.2", 32)
                   .addDnsServer("8.8.8.8")
                   .addDnsServer("8.8.4.4")
                   .addRoute("0.0.0.0", 0)
                   .setMtu(1500);
            
            // 设置启动Intent
            Intent configureIntent = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, configureIntent, PendingIntent.FLAG_IMMUTABLE);
            builder.setConfigureIntent(pendingIntent);
            
            // 建立VPN接口
            vpnInterface = builder.establish();
            
            // 启动VPN处理线程
            vpnThread = new Thread(new VpnRunnable(), "AdBlockVPN");
            vpnThread.start();
            
            Log.i(TAG, "VPN广告拦截服务已启动");
            
        } catch (Exception e) {
            Log.e(TAG, "启动VPN失败", e);
            stopSelf();
        }
    }
    
    private class VpnRunnable implements Runnable {
        @Override
        public void run() {
            try {
                FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
                FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
                
                ByteBuffer packet = ByteBuffer.allocate(32767);
                
                while (!Thread.interrupted()) {
                    // 读取数据包
                    int length = in.read(packet.array());
                    if (length < 0) {
                        break;
                    }
                    
                    // 解析数据包并检查是否为广告
                    if (!isAdPacket(packet, length)) {
                        // 非广告数据包，正常转发
                        out.write(packet.array(), 0, length);
                    } else {
                        Log.d(TAG, "拦截广告数据包");
                        // 广告数据包被拦截
                    }
                    
                    packet.clear();
                }
                
            } catch (IOException e) {
                Log.e(TAG, "VPN处理错误", e);
            } finally {
                closeVpn();
            }
        }
    }
    
    /**
     * 检查数据包是否为广告
     */
    private boolean isAdPacket(ByteBuffer packet, int length) {
        // 这里可以实现更复杂的数据包分析
        // 目前简单检查DNS查询中的广告域名
        
        // 将数据包转换为字符串进行检查
        String packetData = new String(packet.array(), 0, length);
        
        // 检查常见广告域名
        String[] adDomains = {
            "ads.google.com", "doubleclick.net", "facebook.com",
            "admob.com", "applovin.com", "unity3d.com"
        };
        
        for (String domain : adDomains) {
            if (packetData.contains(domain)) {
                return true;
            }
        }
        
        return false;
    }
    
    private void closeVpn() {
        try {
            if (vpnInterface != null) {
                vpnInterface.close();
                vpnInterface = null;
            }
        } catch (IOException e) {
            Log.e(TAG, "关闭VPN接口失败", e);
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        
        if (vpnThread != null) {
            vpnThread.interrupt();
        }
        
        closeVpn();
        Log.i(TAG, "VPN广告拦截服务已停止");
    }
}