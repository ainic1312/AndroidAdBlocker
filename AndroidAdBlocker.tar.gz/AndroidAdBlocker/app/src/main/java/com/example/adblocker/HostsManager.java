package com.example.adblocker;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Hosts文件管理器
 * 用于修改系统Hosts文件来屏蔽广告域名
 */
public class HostsManager {
    private static final String TAG = "HostsManager";
    
    // 广告域名黑名单
    private static final Set<String> AD_DOMAINS = new HashSet<>();
    
    static {
        // 初始化广告域名
        AD_DOMAINS.add("ads.google.com");
        AD_DOMAINS.add("googleadservices.com");
        AD_DOMAINS.add("doubleclick.net");
        AD_DOMAINS.add("admob.com");
        AD_DOMAINS.add("facebook.com");
        AD_DOMAINS.add("fbcdn.net");
        AD_DOMAINS.add("ads.tencent.com");
        AD_DOMAINS.add("baidu.com");
        AD_DOMAINS.add("bdstatic.com");
        AD_DOMAINS.add("alimama.com");
        AD_DOMAINS.add("alicdn.com");
        AD_DOMAINS.add("bytedance.com");
        AD_DOMAINS.add("snssdk.com");
        AD_DOMAINS.add("adcolony.com");
        AD_DOMAINS.add("applovin.com");
        AD_DOMAINS.add("chartboost.com");
        AD_DOMAINS.add("unity3d.com");
        AD_DOMAINS.add("vungle.com");
        AD_DOMAINS.add("ironsrc.com");
    }
    
    /**
     * 更新Hosts文件
     * @param context 上下文
     * @param enableAdBlock 是否启用广告拦截
     */
    public static void updateHostsFile(Context context, boolean enableAdBlock) {
        try {
            File hostsFile = new File("/system/etc/hosts");
            File tempFile = new File(context.getCacheDir(), "hosts_temp");
            
            // 检查是否有写权限
            if (!hostsFile.canWrite()) {
                Log.w(TAG, "没有Hosts文件写权限，需要root权限");
                return;
            }
            
            // 读取原始Hosts文件
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(hostsFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // 移除之前的广告拦截条目
                    if (!line.contains("# AD_BLOCK")) {
                        content.append(line).append("\n");
                    }
                }
            }
            
            // 如果需要启用广告拦截，添加广告域名
            if (enableAdBlock) {
                content.append("\n# AD_BLOCK - 广告域名屏蔽\n");
                for (String domain : AD_DOMAINS) {
                    content.append("127.0.0.1 ").append(domain).append("\n");
                    content.append("::1 ").append(domain).append("\n");
                }
                content.append("# END AD_BLOCK\n");
            }
            
            // 写入临时文件
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
                writer.write(content.toString());
            }
            
            // 替换原始文件（需要root权限）
            Process process = Runtime.getRuntime().exec("su");
            
            // 执行复制命令
            String copyCmd = "cat " + tempFile.getAbsolutePath() + " > " + hostsFile.getAbsolutePath() + "\n";
            process.getOutputStream().write(copyCmd.getBytes());
            process.getOutputStream().flush();
            
            // 刷新DNS缓存
            String flushCmd = "killall -HUP netd\n";
            process.getOutputStream().write(flushCmd.getBytes());
            process.getOutputStream().flush();
            
            process.getOutputStream().close();
            
            int result = process.waitFor();
            if (result == 0) {
                Log.i(TAG, "Hosts文件更新成功");
            } else {
                Log.e(TAG, "Hosts文件更新失败，退出码: " + result);
            }
            
            // 清理临时文件
            tempFile.delete();
            
        } catch (IOException | InterruptedException e) {
            Log.e(TAG, "更新Hosts文件失败", e);
        }
    }
    
    /**
     * 检查广告拦截是否启用
     */
    public static boolean isAdBlockEnabled(Context context) {
        try {
            File hostsFile = new File("/system/etc/hosts");
            try (BufferedReader reader = new BufferedReader(new FileReader(hostsFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains("# AD_BLOCK")) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "检查Hosts文件失败", e);
        }
        
        return false;
    }
}