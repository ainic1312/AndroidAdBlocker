package com.example.adblocker;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.util.Log;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * 安卓网络拦截器
 * 用于拦截和阻止广告网络请求
 */
public class NetworkInterceptor {
    private static final String TAG = "AdBlocker";
    
    // 广告域名黑名单
    private static final Set<String> AD_DOMAINS = new HashSet<>();
    
    static {
        // 初始化广告域名
        AD_DOMAINS.add("ads.google.com");
        AD_DOMAINS.add("googleadservices.com");
        AD_DOMAINS.add("doubleclick.net");
        AD_DOMAINS.add("admob.com");
        AD_DOMAINS.add("facebook.com");
        AD_DOMAINS.add("fbcdn.net");
        AD_DOMAINS.add("ads.tencent.com");
        AD_DOMAINS.add("baidu.com");
        AD_DOMAINS.add("bdstatic.com");
        AD_DOMAINS.add("alimama.com");
        AD_DOMAINS.add("alicdn.com");
        AD_DOMAINS.add("bytedance.com");
        AD_DOMAINS.add("snssdk.com");
        AD_DOMAINS.add("adcolony.com");
        AD_DOMAINS.add("applovin.com");
        AD_DOMAINS.add("chartboost.com");
        AD_DOMAINS.add("unity3d.com");
        AD_DOMAINS.add("vungle.com");
        AD_DOMAINS.add("ironsrc.com");
    }
    
    /**
     * 检查URL是否为广告
     */
    public static boolean isAdUrl(String urlString) {
        try {
            URL url = new URL(urlString);
            String host = url.getHost().toLowerCase();
            
            // 检查完整域名
            if (AD_DOMAINS.contains(host)) {
                return true;
            }
            
            // 检查子域名
            for (String domain : AD_DOMAINS) {
                if (host.endsWith("." + domain)) {
                    return true;
                }
            }
            
            // 检查路径关键词
            String path = url.getPath().toLowerCase();
            String[] adKeywords = {"ads", "ad", "promo", "sponsored", "banner", "interstitial"};
            for (String keyword : adKeywords) {
                if (path.contains(keyword)) {
                    return true;
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "解析URL失败: " + urlString, e);
        }
        
        return false;
    }
    
    /**
     * 拦截广告网络请求
     */
    public static boolean shouldBlockRequest(String url) {
        boolean isAd = isAdUrl(url);
        if (isAd) {
            Log.i(TAG, "拦截广告请求: " + url);
        }
        return isAd;
    }
    
    /**
     * 自定义SSLSocketFactory用于拦截SSL请求
     */
    public static class AdBlockingSSLSocketFactory extends SSLSocketFactory {
        private final SSLSocketFactory delegate;
        
        public AdBlockingSSLSocketFactory(SSLSocketFactory delegate) {
            this.delegate = delegate;
        }
        
        @Override
        public String[] getDefaultCipherSuites() {
            return delegate.getDefaultCipherSuites();
        }
        
        @Override
        public String[] getSupportedCipherSuites() {
            return delegate.getSupportedCipherSuites();
        }
        
        @Override
        public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
            if (shouldBlockRequest("https://" + host)) {
                throw new IOException("广告请求被拦截: " + host);
            }
            return delegate.createSocket(s, host, port, autoClose);
        }
        
        @Override
        public Socket createSocket(String host, int port) throws IOException {
            if (shouldBlockRequest("https://" + host)) {
                throw new IOException("广告请求被拦截: " + host);
            }
            return delegate.createSocket(host, port);
        }
        
        @Override
        public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
            if (shouldBlockRequest("https://" + host)) {
                throw new IOException("广告请求被拦截: " + host);
            }
            return delegate.createSocket(host, port, localHost, localPort);
        }
        
        @Override
        public Socket createSocket(InetAddress host, int port) throws IOException {
            return delegate.createSocket(host, port);
        }
        
        @Override
        public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
            return delegate.createSocket(address, port, localAddress, localPort);
        }
    }
    
    /**
     * 设置网络拦截（Android 7+）
     */
    public static void setupNetworkInterception(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ConnectivityManager connectivityManager = 
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            
            NetworkRequest.Builder requestBuilder = new NetworkRequest.Builder();
            requestBuilder.addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            
            ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    super.onAvailable(network);
                    Log.i(TAG, "网络可用，设置广告拦截");
                }
                
                @Override
                public void onLost(Network network) {
                    super.onLost(network);
                    Log.i(TAG, "网络丢失");
                }
            };
            
            connectivityManager.requestNetwork(requestBuilder.build(), networkCallback);
        }
    }
}