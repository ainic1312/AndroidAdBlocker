package com.example.adblocker;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private Switch adBlockSwitch;
    private Button startVpnBtn;
    private TextView statusText;
    
    private static final int VPN_REQUEST_CODE = 100;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // 初始化UI组件
        adBlockSwitch = findViewById(R.id.ad_block_switch);
        startVpnBtn = findViewById(R.id.start_vpn_btn);
        statusText = findViewById(R.id.status_text);
        
        // 设置开关监听
        adBlockSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                enableAdBlocking();
            } else {
                disableAdBlocking();
            }
        });
        
        // 设置VPN按钮监听
        startVpnBtn.setOnClickListener(v -> startVpnService());
    }
    
    /**
     * 启用广告拦截
     */
    private void enableAdBlocking() {
        // 设置Hosts文件广告拦截
        HostsManager.updateHostsFile(this, true);
        
        // 设置网络拦截
        NetworkInterceptor.setupNetworkInterception(this);
        
        statusText.setText("广告拦截已启用");
        Toast.makeText(this, "广告拦截已启用", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * 禁用广告拦截
     */
    private void disableAdBlocking() {
        // 恢复Hosts文件
        HostsManager.updateHostsFile(this, false);
        
        statusText.setText("广告拦截已禁用");
        Toast.makeText(this, "广告拦截已禁用", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * 启动VPN服务
     */
    private void startVpnService() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            // 需要用户授权
            startActivityForResult(intent, VPN_REQUEST_CODE);
        } else {
            // 已有权限，直接启动
            onActivityResult(VPN_REQUEST_CODE, RESULT_OK, null);
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            // 启动VPN服务
            Intent vpnIntent = new Intent(this, AdBlockVpnService.class);
            startService(vpnIntent);
            
            statusText.setText("VPN广告拦截已启动");
            Toast.makeText(this, "VPN广告拦截已启动", Toast.LENGTH_SHORT).show();
        }
    }
}